// function-1
// function power(a, b) {
//   if (a && b >= 0) {
//     return a ** b;
//   } else {
//     console.log("It is not true");
//   }
// }
// let result = power(35, 2);
// console.log(result);

// function-2
// function mean(a, b) {
//   console.log((a + b) / 2);
//   console.log((a + b) ^ (1 / 2));
// }
// console.log(mean(24, 64));

// function-3
// function sign(a) {
//   if (a < 0) {
//     return -1;
//   } else if (a > 0) {
//     return 1;
//   } else {
//     return 0;
//   }
// }
// let result = sign(0);
// console.log(result);

// function-4
// function numberOfRoots(A, B, C) {
//   d = B ^ (2 - 4 * A * C);
//   if (d < 0) {
//     return 0;
//   } else if (d > 0) {
//     return 2;
//   } else {
//     return 0;
//   }
// }
// let result = numberOfRoots(2, 4, 6);
// console.log(result);

// function-5
// function areaCircle(R) {
//   R = (π * R) ^ 2;
//   return R;
// }
// let result = areaCircle(40);
// console.log(result);

// functon-6
// function sumRange(a, b) {
//   if (a < b) {
//     return 0;
//   } else {
//     let c = a - b;
//     for (i = 1; i <= c; i++) {
//         // bu yogiga nma qilishni bilmadim
//     }
//     }
//   }
// }
// let result = sumRange(81, 10);
// console.log(result);

// function-7
// chunarsiz

// fuction-8
// function isEven(k) {
//   if (k % 2 === 0) {
//     return true;
//   } else {
//     return false;
//   }
// }
// let result = isEven(10);
// console.log(result);

// function-9
// function sortABC(a, b, c) {
//   if (a > b && c) {
//     console.log(a);
//   } else if (b > a && c) {
//     console.log(b);
//   } else if (c > a && b) {
//     console.log(c);
//   }
// }
// sortABC(10, 15, 16);

// function-10
// function isPowerN(k, n) {
//   if (k % n === 0) {
//     return true;
//   } else {
//     return false;
//   }
// }
// let result = isPowerN(24, 6);
// console.log(result);

// function-11
// function isPrime(n) {
//   if (n % 2 === 0) {
//     return false;
//   } else {
//     return true;
//   }
// }
// let result = isPrime(11);
// console.log(result);

// function-12
// function numberOfPrime(n) {
//   for (i = 0; i <= n; i++) {
//     if (i % 2 === 0) {
//       return false;
//     } else if (i % 2 !== 0) {
//       return i;
//     }
//   }
// }
// let result = numberOfPrime(7);
// console.log(result);

// function-13
// function digitNth(k, n) {
//   if (k <= n) {
//     return -1;
//   } else {
//     return 1;
//   }
// }
// let result = digitNth(80, 34);
// console.log(result);

// function-14
// function inverseNumber(n) {
//   console.log((a = Math.floor(n / 100)));
//   console.log((b = Math.floor(n / 1000)));
//   console.log((c = n % 10));
//   console.log(Math.floor((d = n / 10)));
// }
// let result = inverseNumber(2234);
// console.log(result);

// function-15

// function-16
// function factorial(n) {
//   if (n < 0) {
//     console.log(1);
//     return 1;
//   } else {
//     console.log(0);
//     console.log(0);
//   }
// }
// let result = factorial(-2);
// console.log(result);

// function-17
